---
title: "At Ramzunā, we commemorate the 78th anniversary of the Nakba"
description: "نَكْبَة - The Nakba. 78 Years Already."
date: "May 15, 2026"
category: "Palestinian history"
image: "/assets/img/nakba.jpeg"
readTime: "2 min read"
author:
  name: "Shams Mazen Rajab"
  role: "Student Coordinator"
  image: "/assets/img/avatar-placeholder.svg"
---

## At Ramzunā, we remember the Nakba

<p style="text-align: justify;">
In 1948, families were forced to leave their homes, carrying with them memories, keys, and hopes for return. 
</p>

<p style="text-align: justify;">
The Nakba (the catastrophe in English) was the beginning of a journey of exile that continues to this day. 
</p>

<p style="text-align: justify;">
The key is more than metal. It is a symbol of belonging, of a house that still lives on in memory. Generations hold it a as a promise of return. 
</p>

<p style="text-align: justify;">
Children inherit stories of places they have never seen. They grow up with questions about a home that exists only in memory. Yet the longing remains alive in their hearts. 
</p>

<p style="text-align: justify;">
The Nakba was not the end. It was the beginning of resilience, struggle, and holding on to identity. Families continue to walk with hope and determination. Photos, stories, and memories are carried like treasures, reminding us of what was lost, and of what must never be forgotten. Nakba... 
</p>

<p style="text-align: justify;">
<strong>78 Years. Never Forget.</strong>
</p>
